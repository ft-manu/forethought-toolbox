function U(t){return Array.isArray?Array.isArray(t):De(t)==="[object Array]"}function He(t){if(typeof t=="string")return t;let e=t+"";return e=="0"&&1/t==-1/0?"-0":e}function Ge(t){return t==null?"":He(t)}function j(t){return typeof t=="string"}function Re(t){return typeof t=="number"}function Pe(t){return t===!0||t===!1||We(t)&&De(t)=="[object Boolean]"}function Te(t){return typeof t=="object"}function We(t){return Te(t)&&t!==null}function N(t){return t!=null}function me(t){return!t.trim().length}function De(t){return t==null?t===void 0?"[object Undefined]":"[object Null]":Object.prototype.toString.call(t)}const je="Incorrect 'index' type",Ve=t=>`Invalid value for key ${t}`,qe=t=>`Pattern length exceeds max of ${t}.`,Ye=t=>`Missing ${t} property in key`,Ue=t=>`Property 'weight' in key '${t}' must be a positive integer`,we=Object.prototype.hasOwnProperty;class Qe{constructor(e){this._keys=[],this._keyMap={};let o=0;e.forEach(n=>{let r=Fe(n);this._keys.push(r),this._keyMap[r.id]=r,o+=r.weight}),this._keys.forEach(n=>{n.weight/=o})}get(e){return this._keyMap[e]}keys(){return this._keys}toJSON(){return JSON.stringify(this._keys)}}function Fe(t){let e=null,o=null,n=null,r=1,i=null;if(j(t)||U(t))n=t,e=ve(t),o=xe(t);else{if(!we.call(t,"name"))throw new Error(Ye("name"));const a=t.name;if(n=a,we.call(t,"weight")&&(r=t.weight,r<=0))throw new Error(Ue(a));e=ve(a),o=xe(a),i=t.getFn}return{path:e,id:o,weight:r,src:n,getFn:i}}function ve(t){return U(t)?t:t.split(".")}function xe(t){return U(t)?t.join("."):t}function Je(t,e){let o=[],n=!1;const r=(i,a,l)=>{if(N(i))if(!a[l])o.push(i);else{let u=a[l];const h=i[u];if(!N(h))return;if(l===a.length-1&&(j(h)||Re(h)||Pe(h)))o.push(Ge(h));else if(U(h)){n=!0;for(let d=0,g=h.length;d<g;d+=1)r(h[d],a,l+1)}else a.length&&r(h,a,l+1)}};return r(t,j(e)?e.split("."):e,0),n?o:o[0]}const Xe={includeMatches:!1,findAllMatches:!1,minMatchCharLength:1},Ze={isCaseSensitive:!1,ignoreDiacritics:!1,includeScore:!1,keys:[],shouldSort:!0,sortFn:(t,e)=>t.score===e.score?t.idx<e.idx?-1:1:t.score<e.score?-1:1},et={location:0,threshold:.6,distance:100},tt={useExtendedSearch:!1,getFn:Je,ignoreLocation:!1,ignoreFieldNorm:!1,fieldNormWeight:1};var p={...Ze,...Xe,...et,...tt};const ot=/[^ ]+/g;function nt(t=1,e=3){const o=new Map,n=Math.pow(10,e);return{get(r){const i=r.match(ot).length;if(o.has(i))return o.get(i);const a=1/Math.pow(i,.5*t),l=parseFloat(Math.round(a*n)/n);return o.set(i,l),l},clear(){o.clear()}}}class Ce{constructor({getFn:e=p.getFn,fieldNormWeight:o=p.fieldNormWeight}={}){this.norm=nt(o,3),this.getFn=e,this.isCreated=!1,this.setIndexRecords()}setSources(e=[]){this.docs=e}setIndexRecords(e=[]){this.records=e}setKeys(e=[]){this.keys=e,this._keysMap={},e.forEach((o,n)=>{this._keysMap[o.id]=n})}create(){this.isCreated||!this.docs.length||(this.isCreated=!0,j(this.docs[0])?this.docs.forEach((e,o)=>{this._addString(e,o)}):this.docs.forEach((e,o)=>{this._addObject(e,o)}),this.norm.clear())}add(e){const o=this.size();j(e)?this._addString(e,o):this._addObject(e,o)}removeAt(e){this.records.splice(e,1);for(let o=e,n=this.size();o<n;o+=1)this.records[o].i-=1}getValueForItemAtKeyId(e,o){return e[this._keysMap[o]]}size(){return this.records.length}_addString(e,o){if(!N(e)||me(e))return;let n={v:e,i:o,n:this.norm.get(e)};this.records.push(n)}_addObject(e,o){let n={i:o,$:{}};this.keys.forEach((r,i)=>{let a=r.getFn?r.getFn(e):this.getFn(e,r.path);if(N(a)){if(U(a)){let l=[];const u=[{nestedArrIndex:-1,value:a}];for(;u.length;){const{nestedArrIndex:h,value:d}=u.pop();if(N(d))if(j(d)&&!me(d)){let g={v:d,i:h,n:this.norm.get(d)};l.push(g)}else U(d)&&d.forEach((g,y)=>{u.push({nestedArrIndex:y,value:g})})}n.$[i]=l}else if(j(a)&&!me(a)){let l={v:a,n:this.norm.get(a)};n.$[i]=l}}}),this.records.push(n)}toJSON(){return{keys:this.keys,records:this.records}}}function Ie(t,e,{getFn:o=p.getFn,fieldNormWeight:n=p.fieldNormWeight}={}){const r=new Ce({getFn:o,fieldNormWeight:n});return r.setKeys(t.map(Fe)),r.setSources(e),r.create(),r}function st(t,{getFn:e=p.getFn,fieldNormWeight:o=p.fieldNormWeight}={}){const{keys:n,records:r}=t,i=new Ce({getFn:e,fieldNormWeight:o});return i.setKeys(n),i.setIndexRecords(r),i}function pe(t,{errors:e=0,currentLocation:o=0,expectedLocation:n=0,distance:r=p.distance,ignoreLocation:i=p.ignoreLocation}={}){const a=e/t.length;if(i)return a;const l=Math.abs(n-o);return r?a+l/r:l?1:a}function rt(t=[],e=p.minMatchCharLength){let o=[],n=-1,r=-1,i=0;for(let a=t.length;i<a;i+=1){let l=t[i];l&&n===-1?n=i:!l&&n!==-1&&(r=i-1,r-n+1>=e&&o.push([n,r]),n=-1)}return t[i-1]&&i-n>=e&&o.push([n,i-1]),o}const te=32;function it(t,e,o,{location:n=p.location,distance:r=p.distance,threshold:i=p.threshold,findAllMatches:a=p.findAllMatches,minMatchCharLength:l=p.minMatchCharLength,includeMatches:u=p.includeMatches,ignoreLocation:h=p.ignoreLocation}={}){if(e.length>te)throw new Error(qe(te));const d=e.length,g=t.length,y=Math.max(0,Math.min(n,g));let b=i,f=y;const k=l>1||u,E=k?Array(g):[];let L;for(;(L=t.indexOf(e,f))>-1;){let I=pe(e,{currentLocation:L,expectedLocation:y,distance:r,ignoreLocation:h});if(b=Math.min(I,b),f=L+d,k){let T=0;for(;T<d;)E[L+T]=1,T+=1}}f=-1;let K=[],F=1,S=d+g;const B=1<<d-1;for(let I=0;I<d;I+=1){let T=0,G=S;for(;T<G;)pe(e,{errors:I,currentLocation:y+G,expectedLocation:y,distance:r,ignoreLocation:h})<=b?T=G:S=G,G=Math.floor((S-T)/2+T);S=G;let ne=Math.max(1,y-G+1),P=a?g:Math.min(y+G,g)+d,O=Array(P+2);O[P+1]=(1<<I)-1;for(let M=P;M>=ne;M-=1){let $=M-1,he=o[t.charAt($)];if(k&&(E[$]=+!!he),O[M]=(O[M+1]<<1|1)&he,I&&(O[M]|=(K[M+1]|K[M])<<1|1|K[M+1]),O[M]&B&&(F=pe(e,{errors:I,currentLocation:$,expectedLocation:y,distance:r,ignoreLocation:h}),F<=b)){if(b=F,f=$,f<=y)break;ne=Math.max(1,2*y-f)}}if(pe(e,{errors:I+1,currentLocation:y,expectedLocation:y,distance:r,ignoreLocation:h})>b)break;K=O}const oe={isMatch:f>=0,score:Math.max(.001,F)};if(k){const I=rt(E,l);I.length?u&&(oe.indices=I):oe.isMatch=!1}return oe}function ct(t){let e={};for(let o=0,n=t.length;o<n;o+=1){const r=t.charAt(o);e[r]=(e[r]||0)|1<<n-o-1}return e}const ge=String.prototype.normalize?t=>t.normalize("NFD").replace(/[\u0300-\u036F\u0483-\u0489\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06DC\u06DF-\u06E4\u06E7\u06E8\u06EA-\u06ED\u0711\u0730-\u074A\u07A6-\u07B0\u07EB-\u07F3\u07FD\u0816-\u0819\u081B-\u0823\u0825-\u0827\u0829-\u082D\u0859-\u085B\u08D3-\u08E1\u08E3-\u0903\u093A-\u093C\u093E-\u094F\u0951-\u0957\u0962\u0963\u0981-\u0983\u09BC\u09BE-\u09C4\u09C7\u09C8\u09CB-\u09CD\u09D7\u09E2\u09E3\u09FE\u0A01-\u0A03\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A70\u0A71\u0A75\u0A81-\u0A83\u0ABC\u0ABE-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AE2\u0AE3\u0AFA-\u0AFF\u0B01-\u0B03\u0B3C\u0B3E-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B62\u0B63\u0B82\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD7\u0C00-\u0C04\u0C3E-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C62\u0C63\u0C81-\u0C83\u0CBC\u0CBE-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CE2\u0CE3\u0D00-\u0D03\u0D3B\u0D3C\u0D3E-\u0D44\u0D46-\u0D48\u0D4A-\u0D4D\u0D57\u0D62\u0D63\u0D82\u0D83\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DF2\u0DF3\u0E31\u0E34-\u0E3A\u0E47-\u0E4E\u0EB1\u0EB4-\u0EB9\u0EBB\u0EBC\u0EC8-\u0ECD\u0F18\u0F19\u0F35\u0F37\u0F39\u0F3E\u0F3F\u0F71-\u0F84\u0F86\u0F87\u0F8D-\u0F97\u0F99-\u0FBC\u0FC6\u102B-\u103E\u1056-\u1059\u105E-\u1060\u1062-\u1064\u1067-\u106D\u1071-\u1074\u1082-\u108D\u108F\u109A-\u109D\u135D-\u135F\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17B4-\u17D3\u17DD\u180B-\u180D\u1885\u1886\u18A9\u1920-\u192B\u1930-\u193B\u1A17-\u1A1B\u1A55-\u1A5E\u1A60-\u1A7C\u1A7F\u1AB0-\u1ABE\u1B00-\u1B04\u1B34-\u1B44\u1B6B-\u1B73\u1B80-\u1B82\u1BA1-\u1BAD\u1BE6-\u1BF3\u1C24-\u1C37\u1CD0-\u1CD2\u1CD4-\u1CE8\u1CED\u1CF2-\u1CF4\u1CF7-\u1CF9\u1DC0-\u1DF9\u1DFB-\u1DFF\u20D0-\u20F0\u2CEF-\u2CF1\u2D7F\u2DE0-\u2DFF\u302A-\u302F\u3099\u309A\uA66F-\uA672\uA674-\uA67D\uA69E\uA69F\uA6F0\uA6F1\uA802\uA806\uA80B\uA823-\uA827\uA880\uA881\uA8B4-\uA8C5\uA8E0-\uA8F1\uA8FF\uA926-\uA92D\uA947-\uA953\uA980-\uA983\uA9B3-\uA9C0\uA9E5\uAA29-\uAA36\uAA43\uAA4C\uAA4D\uAA7B-\uAA7D\uAAB0\uAAB2-\uAAB4\uAAB7\uAAB8\uAABE\uAABF\uAAC1\uAAEB-\uAAEF\uAAF5\uAAF6\uABE3-\uABEA\uABEC\uABED\uFB1E\uFE00-\uFE0F\uFE20-\uFE2F]/g,""):t=>t;class Oe{constructor(e,{location:o=p.location,threshold:n=p.threshold,distance:r=p.distance,includeMatches:i=p.includeMatches,findAllMatches:a=p.findAllMatches,minMatchCharLength:l=p.minMatchCharLength,isCaseSensitive:u=p.isCaseSensitive,ignoreDiacritics:h=p.ignoreDiacritics,ignoreLocation:d=p.ignoreLocation}={}){if(this.options={location:o,threshold:n,distance:r,includeMatches:i,findAllMatches:a,minMatchCharLength:l,isCaseSensitive:u,ignoreDiacritics:h,ignoreLocation:d},e=u?e:e.toLowerCase(),e=h?ge(e):e,this.pattern=e,this.chunks=[],!this.pattern.length)return;const g=(b,f)=>{this.chunks.push({pattern:b,alphabet:ct(b),startIndex:f})},y=this.pattern.length;if(y>te){let b=0;const f=y%te,k=y-f;for(;b<k;)g(this.pattern.substr(b,te),b),b+=te;if(f){const E=y-te;g(this.pattern.substr(E),E)}}else g(this.pattern,0)}searchIn(e){const{isCaseSensitive:o,ignoreDiacritics:n,includeMatches:r}=this.options;if(e=o?e:e.toLowerCase(),e=n?ge(e):e,this.pattern===e){let k={isMatch:!0,score:0};return r&&(k.indices=[[0,e.length-1]]),k}const{location:i,distance:a,threshold:l,findAllMatches:u,minMatchCharLength:h,ignoreLocation:d}=this.options;let g=[],y=0,b=!1;this.chunks.forEach(({pattern:k,alphabet:E,startIndex:L})=>{const{isMatch:K,score:F,indices:S}=it(e,k,E,{location:i+L,distance:a,threshold:l,findAllMatches:u,minMatchCharLength:h,includeMatches:r,ignoreLocation:d});K&&(b=!0),y+=F,K&&S&&(g=[...g,...S])});let f={isMatch:b,score:b?y/this.chunks.length:1};return b&&r&&(f.indices=g),f}}class ee{constructor(e){this.pattern=e}static isMultiMatch(e){return Se(e,this.multiRegex)}static isSingleMatch(e){return Se(e,this.singleRegex)}search(){}}function Se(t,e){const o=t.match(e);return o?o[1]:null}class at extends ee{constructor(e){super(e)}static get type(){return"exact"}static get multiRegex(){return/^="(.*)"$/}static get singleRegex(){return/^=(.*)$/}search(e){const o=e===this.pattern;return{isMatch:o,score:o?0:1,indices:[0,this.pattern.length-1]}}}class lt extends ee{constructor(e){super(e)}static get type(){return"inverse-exact"}static get multiRegex(){return/^!"(.*)"$/}static get singleRegex(){return/^!(.*)$/}search(e){const n=e.indexOf(this.pattern)===-1;return{isMatch:n,score:n?0:1,indices:[0,e.length-1]}}}class ut extends ee{constructor(e){super(e)}static get type(){return"prefix-exact"}static get multiRegex(){return/^\^"(.*)"$/}static get singleRegex(){return/^\^(.*)$/}search(e){const o=e.startsWith(this.pattern);return{isMatch:o,score:o?0:1,indices:[0,this.pattern.length-1]}}}class ht extends ee{constructor(e){super(e)}static get type(){return"inverse-prefix-exact"}static get multiRegex(){return/^!\^"(.*)"$/}static get singleRegex(){return/^!\^(.*)$/}search(e){const o=!e.startsWith(this.pattern);return{isMatch:o,score:o?0:1,indices:[0,e.length-1]}}}class dt extends ee{constructor(e){super(e)}static get type(){return"suffix-exact"}static get multiRegex(){return/^"(.*)"\$$/}static get singleRegex(){return/^(.*)\$$/}search(e){const o=e.endsWith(this.pattern);return{isMatch:o,score:o?0:1,indices:[e.length-this.pattern.length,e.length-1]}}}class pt extends ee{constructor(e){super(e)}static get type(){return"inverse-suffix-exact"}static get multiRegex(){return/^!"(.*)"\$$/}static get singleRegex(){return/^!(.*)\$$/}search(e){const o=!e.endsWith(this.pattern);return{isMatch:o,score:o?0:1,indices:[0,e.length-1]}}}class $e extends ee{constructor(e,{location:o=p.location,threshold:n=p.threshold,distance:r=p.distance,includeMatches:i=p.includeMatches,findAllMatches:a=p.findAllMatches,minMatchCharLength:l=p.minMatchCharLength,isCaseSensitive:u=p.isCaseSensitive,ignoreDiacritics:h=p.ignoreDiacritics,ignoreLocation:d=p.ignoreLocation}={}){super(e),this._bitapSearch=new Oe(e,{location:o,threshold:n,distance:r,includeMatches:i,findAllMatches:a,minMatchCharLength:l,isCaseSensitive:u,ignoreDiacritics:h,ignoreLocation:d})}static get type(){return"fuzzy"}static get multiRegex(){return/^"(.*)"$/}static get singleRegex(){return/^(.*)$/}search(e){return this._bitapSearch.searchIn(e)}}class ze extends ee{constructor(e){super(e)}static get type(){return"include"}static get multiRegex(){return/^'"(.*)"$/}static get singleRegex(){return/^'(.*)$/}search(e){let o=0,n;const r=[],i=this.pattern.length;for(;(n=e.indexOf(this.pattern,o))>-1;)o=n+i,r.push([n,o-1]);const a=!!r.length;return{isMatch:a,score:a?0:1,indices:r}}}const ye=[at,ze,ut,ht,pt,dt,lt,$e],_e=ye.length,gt=/ +(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/,ft="|";function mt(t,e={}){return t.split(ft).map(o=>{let n=o.trim().split(gt).filter(i=>i&&!!i.trim()),r=[];for(let i=0,a=n.length;i<a;i+=1){const l=n[i];let u=!1,h=-1;for(;!u&&++h<_e;){const d=ye[h];let g=d.isMultiMatch(l);g&&(r.push(new d(g,e)),u=!0)}if(!u)for(h=-1;++h<_e;){const d=ye[h];let g=d.isSingleMatch(l);if(g){r.push(new d(g,e));break}}}return r})}const xt=new Set([$e.type,ze.type]);class yt{constructor(e,{isCaseSensitive:o=p.isCaseSensitive,ignoreDiacritics:n=p.ignoreDiacritics,includeMatches:r=p.includeMatches,minMatchCharLength:i=p.minMatchCharLength,ignoreLocation:a=p.ignoreLocation,findAllMatches:l=p.findAllMatches,location:u=p.location,threshold:h=p.threshold,distance:d=p.distance}={}){this.query=null,this.options={isCaseSensitive:o,ignoreDiacritics:n,includeMatches:r,minMatchCharLength:i,findAllMatches:l,ignoreLocation:a,location:u,threshold:h,distance:d},e=o?e:e.toLowerCase(),e=n?ge(e):e,this.pattern=e,this.query=mt(this.pattern,this.options)}static condition(e,o){return o.useExtendedSearch}searchIn(e){const o=this.query;if(!o)return{isMatch:!1,score:1};const{includeMatches:n,isCaseSensitive:r,ignoreDiacritics:i}=this.options;e=r?e:e.toLowerCase(),e=i?ge(e):e;let a=0,l=[],u=0;for(let h=0,d=o.length;h<d;h+=1){const g=o[h];l.length=0,a=0;for(let y=0,b=g.length;y<b;y+=1){const f=g[y],{isMatch:k,indices:E,score:L}=f.search(e);if(k){if(a+=1,u+=L,n){const K=f.constructor.type;xt.has(K)?l=[...l,...E]:l.push(E)}}else{u=0,a=0,l.length=0;break}}if(a){let y={isMatch:!0,score:u/a};return n&&(y.indices=l),y}}return{isMatch:!1,score:1}}}const be=[];function bt(...t){be.push(...t)}function ke(t,e){for(let o=0,n=be.length;o<n;o+=1){let r=be[o];if(r.condition(t,e))return new r(t,e)}return new Oe(t,e)}const fe={AND:"$and",OR:"$or"},Ae={PATH:"$path",PATTERN:"$val"},Ee=t=>!!(t[fe.AND]||t[fe.OR]),kt=t=>!!t[Ae.PATH],At=t=>!U(t)&&Te(t)&&!Ee(t),Le=t=>({[fe.AND]:Object.keys(t).map(e=>({[e]:t[e]}))});function Ne(t,e,{auto:o=!0}={}){const n=r=>{let i=Object.keys(r);const a=kt(r);if(!a&&i.length>1&&!Ee(r))return n(Le(r));if(At(r)){const u=a?r[Ae.PATH]:i[0],h=a?r[Ae.PATTERN]:r[u];if(!j(h))throw new Error(Ve(u));const d={keyId:xe(u),pattern:h};return o&&(d.searcher=ke(h,e)),d}let l={children:[],operator:i[0]};return i.forEach(u=>{const h=r[u];U(h)&&h.forEach(d=>{l.children.push(n(d))})}),l};return Ee(t)||(t=Le(t)),n(t)}function Et(t,{ignoreFieldNorm:e=p.ignoreFieldNorm}){t.forEach(o=>{let n=1;o.matches.forEach(({key:r,norm:i,score:a})=>{const l=r?r.weight:null;n*=Math.pow(a===0&&l?Number.EPSILON:a,(l||1)*(e?1:i))}),o.score=n})}function Ct(t,e){const o=t.matches;e.matches=[],N(o)&&o.forEach(n=>{if(!N(n.indices)||!n.indices.length)return;const{indices:r,value:i}=n;let a={indices:r,value:i};n.key&&(a.key=n.key.src),n.idx>-1&&(a.refIndex=n.idx),e.matches.push(a)})}function wt(t,e){e.score=t.score}function vt(t,e,{includeMatches:o=p.includeMatches,includeScore:n=p.includeScore}={}){const r=[];return o&&r.push(Ct),n&&r.push(wt),t.map(i=>{const{idx:a}=i,l={item:e[a],refIndex:a};return r.length&&r.forEach(u=>{u(i,l)}),l})}class ue{constructor(e,o={},n){this.options={...p,...o},this.options.useExtendedSearch,this._keyStore=new Qe(this.options.keys),this.setCollection(e,n)}setCollection(e,o){if(this._docs=e,o&&!(o instanceof Ce))throw new Error(je);this._myIndex=o||Ie(this.options.keys,this._docs,{getFn:this.options.getFn,fieldNormWeight:this.options.fieldNormWeight})}add(e){N(e)&&(this._docs.push(e),this._myIndex.add(e))}remove(e=()=>!1){const o=[];for(let n=0,r=this._docs.length;n<r;n+=1){const i=this._docs[n];e(i,n)&&(this.removeAt(n),n-=1,r-=1,o.push(i))}return o}removeAt(e){this._docs.splice(e,1),this._myIndex.removeAt(e)}getIndex(){return this._myIndex}search(e,{limit:o=-1}={}){const{includeMatches:n,includeScore:r,shouldSort:i,sortFn:a,ignoreFieldNorm:l}=this.options;let u=j(e)?j(this._docs[0])?this._searchStringList(e):this._searchObjectList(e):this._searchLogical(e);return Et(u,{ignoreFieldNorm:l}),i&&u.sort(a),Re(o)&&o>-1&&(u=u.slice(0,o)),vt(u,this._docs,{includeMatches:n,includeScore:r})}_searchStringList(e){const o=ke(e,this.options),{records:n}=this._myIndex,r=[];return n.forEach(({v:i,i:a,n:l})=>{if(!N(i))return;const{isMatch:u,score:h,indices:d}=o.searchIn(i);u&&r.push({item:i,idx:a,matches:[{score:h,value:i,norm:l,indices:d}]})}),r}_searchLogical(e){const o=Ne(e,this.options),n=(l,u,h)=>{if(!l.children){const{keyId:g,searcher:y}=l,b=this._findMatches({key:this._keyStore.get(g),value:this._myIndex.getValueForItemAtKeyId(u,g),searcher:y});return b&&b.length?[{idx:h,item:u,matches:b}]:[]}const d=[];for(let g=0,y=l.children.length;g<y;g+=1){const b=l.children[g],f=n(b,u,h);if(f.length)d.push(...f);else if(l.operator===fe.AND)return[]}return d},r=this._myIndex.records,i={},a=[];return r.forEach(({$:l,i:u})=>{if(N(l)){let h=n(o,l,u);h.length&&(i[u]||(i[u]={idx:u,item:l,matches:[]},a.push(i[u])),h.forEach(({matches:d})=>{i[u].matches.push(...d)}))}}),a}_searchObjectList(e){const o=ke(e,this.options),{keys:n,records:r}=this._myIndex,i=[];return r.forEach(({$:a,i:l})=>{if(!N(a))return;let u=[];n.forEach((h,d)=>{u.push(...this._findMatches({key:h,value:a[d],searcher:o}))}),u.length&&i.push({idx:l,item:a,matches:u})}),i}_findMatches({key:e,value:o,searcher:n}){if(!N(o))return[];let r=[];if(U(o))o.forEach(({v:i,i:a,n:l})=>{if(!N(i))return;const{isMatch:u,score:h,indices:d}=n.searchIn(i);u&&r.push({score:h,key:e,value:i,idx:a,norm:l,indices:d})});else{const{v:i,n:a}=o,{isMatch:l,score:u,indices:h}=n.searchIn(i);l&&r.push({score:u,key:e,value:i,norm:a,indices:h})}return r}}ue.version="7.1.0";ue.createIndex=Ie;ue.parseIndex=st;ue.config=p;ue.parseQuery=Ne;bt(yt);const ae={SEARCH_HISTORY:"searchHistory",SEARCH_SUGGESTIONS:"searchSuggestions"};document.getElementById("forethought-shadow-host")?console.log("Modal already exists. Skipping injection."):_t();function le(){return typeof chrome<"u"&&chrome.runtime&&typeof chrome.runtime.sendMessage=="function"}function ce(t,e,o=0){if(!le()){console.warn("Messaging skipped: Extension context invalid."),e==null||e(null);return}try{chrome.runtime.sendMessage(t,n=>{var r;if(chrome.runtime.lastError||!n){const i=((r=chrome.runtime.lastError)==null?void 0:r.message)||"No response";console.warn("Message failed:",i),o<2?setTimeout(()=>{ce(t,e,o+1)},100):e==null||e(null);return}e==null||e(n)})}catch(n){console.error("sendMessage threw exception:",n),e==null||e(null)}}function Be(t){const e=t.querySelector("#spinner"),o=t.querySelector("#searchResults");if(e&&(e.style.display="none"),o){const n=document.createElement("div");n.textContent="🚫 Extension messaging is not available.",o.appendChild(n)}}function de(t,e){if(!le()){console.warn("Messaging skipped: Extension context invalid.");return}try{chrome.storage.local.get(t,e)}catch(o){console.warn("Storage get failed:",o)}}function Me(t,e){if(!le()){console.warn("Storage set skipped: Extension context invalid.");return}try{chrome.storage.local.set(t,e)}catch(o){console.warn("Storage set failed:",o)}}function St(){const t=window.location.href,o=new URLSearchParams(window.location.search).get("org");if(t.includes("dashboard")&&o&&!window.__bookmarkletAlreadyRan){let h=function(f,k=0){const E=document.querySelector(f);return E||(k>=l?null:new Promise(L=>{setTimeout(()=>{L(h(f,k+1))},u)}))},g=function(f){const k=document.querySelector('[data-testid="change-org"]');k?(k.click(),setTimeout(()=>y(0),u)):f<l?setTimeout(()=>g(f+1),u):alert("❌ 'Change Org' button not found after retries.")},y=function(f){const k=document.querySelector("input.SearchBar-input");k?(k.focus(),k.value=o,k.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>b(0),u)):f<l?setTimeout(()=>y(f+1),u):alert("❌ Search bar not found.")},b=function(f){const k=[...document.querySelectorAll("button.ModalItem-container")].find(L=>L.innerText.includes(o)),E=document.querySelector(".BreakdownModal-applyBreakdownButton");k&&E?(k.click(),setTimeout(()=>E.click(),300)):f<l?setTimeout(()=>b(f+1),u):alert("❌ Org or Confirm button not found.")};var n=h,r=g,i=y,a=b;window.__bookmarkletAlreadyRan=!0;const l=20,u=500;async function d(){const f=await h('button[aria-label="Account Setting"]');if(!f){alert("❌ Profile button not found after waiting.");return}f.click(),g(0)}d()}}function _t(){const t=document.createElement("div");t.id="forethought-shadow-host",document.body.appendChild(t);const e=t.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=`
    #overlay {
  position: fixed;
  top: 0;
  left: 0;
  height: 100vh;
  width: 100vw;
  background: rgba(0, 0, 0, 0.5);
  opacity: 0;
  pointer-events: none;
  z-index: 9998;
  backdrop-filter: blur(5px);
  transition: opacity 0.3s ease;
}

#overlay.active {
  opacity: 1;
  pointer-events: auto;
}

#modal {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) scale(0.95);
  background: #1a1c23;
  padding: 20px;
  border-radius: 12px;
  width: 90%;
  max-width: 500px;
  min-height: 200px;
  max-height: 90vh;
  overflow-y: auto;
  will-change: transform;
  opacity: 0;
  pointer-events: none;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  color: white;
  box-shadow: 0 10px 30px rgba(0,0,0,0.6);
  backdrop-filter: blur(10px);
  transition: opacity 0.3s ease, transform 0.3s ease;
}

#modal.active {
  opacity: 1;
  pointer-events: auto;
  transform: translate(-50%, -50%) scale(1);
}

#searchInput {
  width: 100%;
  padding: 12px 16px;
  margin-bottom: 12px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  background: #2e3138;
  color: white;
  outline: none;
  box-sizing: border-box;
  position: relative;
  z-index: 2;
}

.suggestion-list {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  background: #2e3138;
  border-radius: 8px;
  margin-top: 4px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  z-index: 1;
  max-height: 200px;
  overflow-y: auto;
  transform: translateY(0);
  transition: transform 0.2s ease;
}

#searchResults {
  list-style: none;
  padding: 0;
  margin: 0;
  max-height: calc(90vh - 120px);
  overflow-y: auto;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  gap: 0px;
  position: relative;
  z-index: 1;
}

#searchResults li {
  background: #2e3138;
  padding: 12px 16px;
  border-bottom: 1px solid rgba(255,255,255,0.1);
  border-radius: 0px;
  cursor: pointer;
  font-size: 16px;
  transition: background 0.2s ease, transform 0.2s ease, opacity 0.3s ease;
  opacity: 0;
  transform: translateY(10px);
}

#searchResults li.show {
  opacity: 1;
  transform: translateY(0);
}

    #searchResults li.active,
    #searchResults li.active:hover {
      background: #38404d !important;
    }

    #modal.light-mode #searchResults li.active,
    #modal.light-mode #searchResults li.active:hover {
      background: #e5e7eb !important;
      color: #222;
}

#settingsWrapper {
      position: fixed;
      bottom: 32px;
      right: 32px;
  display: flex;
  align-items: center;
  gap: 8px;
      z-index: 10001;
}

#settingsButton {
  background: rgba(255,255,255,0.15);
  border: none;
  color: white;
  padding: 6px 10px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 18px;
  z-index: 10000;
  transition: background 0.3s;
}

#settingsButton:hover {
  background: rgba(255,255,255,0.25);
}

#modal.light-mode {
  background: #ffffff;
  color: #222;
}

#modal.light-mode #searchInput {
  background: #f3f4f6;
  color: #222;
  border: 1px solid #ccc;
}

#searchResults li.light-mode {
  color: #222;
}

    .switch {
  position: relative;
  display: inline-block;
  width: 40px;
  height: 24px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0; left: 0;
  right: 0; bottom: 0;
  background-color: #ccc;
  transition: .4s;
  border-radius: 24px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 18px;
  width: 18px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  transition: .4s;
  border-radius: 50%;
}

input:checked + .slider {
  background-color: #4caf50;
}

input:checked + .slider:before {
  transform: translateX(16px);
}

#opacitySlider {
  -webkit-appearance: none;
  appearance: none;
  height: 6px;
  width: 140px;
  background: #888;
  border-radius: 5px;
  outline: none;
  margin-top: 4px;
  cursor: pointer;
  transition: box-shadow 0.3s ease;
}

#opacitySlider:hover {
  box-shadow: 0 0 8px 2px #4caf50;
}

#opacitySlider:active {
  box-shadow: 0 0 12px 4px #4caf50;
}

#opacitySlider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #ffffff;
  border: 2px solid #4caf50;
  cursor: pointer;
  transition: background 0.3s ease;
}

#opacitySlider::-moz-range-thumb {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #ffffff;
  border: 2px solid #4caf50;
  cursor: pointer;
  transition: background 0.3s ease;
}

    #modal.light-mode #searchFilters select {
      background: #f3f4f6;
      color: #222;
      border: 1px solid #ccc;
    }

    #modal.light-mode .suggestion-list {
      background: #f3f4f6;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    #modal.light-mode .suggestion-list div:hover {
      background: #e5e7eb;
    }

    #modal.light-mode .suggestion-list div {
      color: #222;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
}
  `,e.appendChild(o);const n=document.createElement("div");n.id="overlay";const r=document.createElement("div");r.id="settingsWrapper",r.innerHTML=`
  <button id="settingsButton">⚙️</button>
  <div id="settingsPanel" style="display: none; flex-direction: column; gap: 8px; margin-left: 8px; margin-top: 8px; min-width: 220px;">
    <div id="opacityControl" style="display: flex; flex-direction: column; gap: 4px;">
      <label for="opacitySlider" style="font-size: 12px; color: white;">Background Opacity</label>
      <input type="range" id="opacitySlider" min="0.5" max="1" step="0.05" value="0.8" style="width: 120px;" />
    </div>
    <div id="themeWrapper" style="display: flex; align-items: center; gap: 6px;">
      <span id="themeIcon" style="font-size: 18px;">🌙</span>
      <label class="switch">
        <input type="checkbox" id="themeToggle">
        <span class="slider"></span>
      </label>
      <span style="font-size: 13px; margin-left: 8px;">Light/Dark Mode</span>
    </div>
    <div id="expandRecentWrapper" style="display: flex; align-items: center; gap: 6px;">
  <span style="font-size: 16px;">📌 Expand Recent</span>
  <label class="switch">
    <input type="checkbox" id="expandRecentToggle">
    <span class="slider"></span>
  </label>
    <div id="recentLimitWrapper" style="display: flex; align-items: center; gap: 6px;">
  <span style="font-size: 14px;">🆕 Recent Limit</span>
  <input type="number" id="recentLimitInput" min="1" max="50" value="5" style="width: 50px; padding: 4px; border-radius: 4px; border: none; text-align: center;">
</div>
</div>
<div id="expandTopWrapper" style="display: flex; align-items: center; gap: 6px;">
  <span style="font-size: 16px;">📌 Expand Top</span>
  <label class="switch">
    <input type="checkbox" id="expandTopToggle">
    <span class="slider"></span>
  </label>
<div id="topLimitWrapper" style="display: flex; align-items: center; gap: 6px;">
  <span style="font-size: 14px;">🌟 Top Limit</span>
  <input type="number" id="topLimitInput" min="1" max="50" value="5" style="width: 50px; padding: 4px; border-radius: 4px; border: none; text-align: center;">
</div>
</div>
<button id="resetClicksButton" style="margin-top: 8px; padding: 6px 10px; font-size: 14px; border: none; border-radius: 8px; background: rgba(255,255,255,0.15); color: white; cursor: pointer;">
  🔄 Reset Click Stats
</button>
    <button id="onboardingTourButton" style="margin-top: 8px; padding: 6px 10px; font-size: 14px; border: none; border-radius: 8px; background: rgba(59,130,246,0.15); color: white; cursor: pointer; transition: background 0.2s ease;">
      🚀 Onboarding Tour
    </button>
  </div>
    
`,n.appendChild(r);const i=document.createElement("div");i.id="modal",i.innerHTML=`
  <input id="searchInput" type="text" placeholder="Search bookmarks..." />
  <div id="spinner" style="display: none; margin: 20px auto; width: 40px; height: 40px; border: 4px solid rgba(255,255,255,0.3); border-top: 4px solid #4caf50; border-radius: 50%; animation: spin 1s linear infinite;"></div>
  <ul id="searchResults"></ul>
`,e.appendChild(n),e.appendChild(i);const a=i.querySelector("#searchInput");i.querySelector("#searchResults");const l=r.querySelector("#settingsButton"),u=r.querySelector("#settingsPanel"),h=r.querySelector("#opacitySlider"),d=r.querySelector("#themeToggle"),g=r.querySelector("#themeIcon");function y(){chrome.storage.local.get("forethought_theme",s=>{let c=s.forethought_theme;c||(c=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light",chrome.storage.local.set({forethought_theme:c})),c==="light"?(i.classList.add("light-mode"),d.checked=!0,g.textContent="☀️"):(i.classList.remove("light-mode"),d.checked=!1,g.textContent="🌙")})}d.addEventListener("change",s=>{s.target.checked?(i.classList.add("light-mode"),chrome.storage.local.set({forethought_theme:"light"}),g.textContent="☀️"):(i.classList.remove("light-mode"),chrome.storage.local.set({forethought_theme:"dark"}),g.textContent="🌙")}),y();function b(){chrome.storage.local.get("forethought_overlay_opacity",s=>{const c=s.forethought_overlay_opacity;c!=null?(n.style.background=`rgba(0, 0, 0, ${c})`,h.value=c):n.style.background="rgba(0, 0, 0, 0.8)"})}h.oninput=s=>{const c=s.target.value;n.style.background=`rgba(0, 0, 0, ${c})`,chrome.storage.local.set({forethought_overlay_opacity:c})},b();function f(){const s=i.querySelector("#searchResults");let c=null,x=null;return s&&s.querySelectorAll("div").forEach(A=>{var H,D;A.previousSibling&&((H=A.previousSibling.textContent)!=null&&H.includes("Recently Added"))&&(c=A),A.previousSibling&&((D=A.previousSibling.textContent)!=null&&D.includes("Top Bookmarks"))&&(x=A)}),{recentList:c,topList:x}}chrome.storage.onChanged.addListener((s,c)=>{if(c==="local"){if(s.forethought_overlay_opacity){const x=s.forethought_overlay_opacity.newValue;x!==void 0&&n&&(n.style.background=`rgba(0, 0, 0, ${x})`,h&&(h.value=x))}(s.forethought_expandRecent||s.forethought_expandTop||s.forethought_recentLimit||s.forethought_topLimit)&&(i.classList.contains("active")&&ce({type:"GET_BOOKMARKS"},x=>{const C=(x==null?void 0:x.bookmarks)||[];de("bookmarkClicks",A=>{const H=(A==null?void 0:A.bookmarkClicks)||{};F(C,H,i);const{recentList:D,topList:Q}=f();s.forethought_expandRecent&&D&&(D.style.display=s.forethought_expandRecent.newValue?"block":"none"),s.forethought_expandTop&&Q&&(Q.style.display=s.forethought_expandTop.newValue?"block":"none")})}),P&&s.forethought_expandRecent&&(P.checked=s.forethought_expandRecent.newValue===!0||s.forethought_expandRecent.newValue==="true"),O&&s.forethought_expandTop&&(O.checked=s.forethought_expandTop.newValue===!0||s.forethought_expandTop.newValue==="true"),se&&s.forethought_recentLimit&&(se.value=s.forethought_recentLimit.newValue),M&&s.forethought_topLimit&&(M.value=s.forethought_topLimit.newValue))}}),l.onclick=s=>{s.stopPropagation(),u.style.display=u.style.display==="none"?"flex":"none",l.classList.add("rotate"),setTimeout(()=>{l.classList.remove("rotate")},500)};function k(s){const c=document.createElement("div");c.id="global-search-onboarding",c.style.position="fixed",c.style.top="50%",c.style.left="50%",c.style.transform="translate(-50%, -50%)",c.style.background="white",c.style.color="#222",c.style.padding="32px 28px",c.style.borderRadius="16px",c.style.boxShadow="0 8px 32px rgba(0,0,0,0.18)",c.style.zIndex="10001",c.style.maxWidth="90vw",c.style.minWidth="320px",c.style.textAlign="center",c.innerHTML=`
      <h2 style="font-size: 1.5rem; font-weight: bold; margin-bottom: 1rem;">Welcome to Global Search!</h2>
      <ul style="text-align: left; margin: 0 auto 1.5rem auto; max-width: 340px; font-size: 1rem; line-height: 1.6; color: #333;">
        <li>🔍 <b>Search bookmarks instantly</b> with <kbd style='background:#eee;padding:2px 6px;border-radius:4px;'>Cmd+K</kbd> or <kbd style='background:#eee;padding:2px 6px;border-radius:4px;'>Ctrl+K</kbd></li>
        <li>↔️ Navigate results with <kbd style='background:#eee;padding:2px 6px;border-radius:4px;'>↑</kbd> <kbd style='background:#eee;padding:2px 6px;border-radius:4px;'>↓</kbd> and <kbd style='background:#eee;padding:2px 6px;border-radius:4px;'>Enter</kbd></li>
        <li>📊 View your most used and recently added bookmarks</li>
        <li>⚙️ Customize settings in the bottom right</li>
        <li>🌗 Light/Dark mode support</li>
      </ul>
      <button id="closeOnboardingBtn" style="margin-top: 1rem; padding: 10px 24px; background: #22c55e; color: white; border: none; border-radius: 8px; font-size: 1rem; cursor: pointer;">Got it!</button>
    `,s.appendChild(c),c.querySelector("#closeOnboardingBtn").onclick=()=>{c.remove(),Me({seenGlobalSearchOnboarding:!0})}}function E(){n.classList.add("active"),i.classList.add("active"),a.focus(),de(["seenGlobalSearchOnboarding","extensionVersion"],s=>{const c=chrome.runtime.getManifest().version;(!s.seenGlobalSearchOnboarding||!s.extensionVersion||s.extensionVersion!==c)&&(k(e),Me({seenGlobalSearchOnboarding:!0,extensionVersion:c}))}),setTimeout(()=>{K(i)},150)}function L(){n.classList.remove("active"),i.classList.remove("active")}function K(s){const c=s.querySelector("#spinner"),x=s.querySelector("#searchResults"),C=s.querySelector("#searchInput");if(c&&(c.style.display="block"),x&&(x.innerHTML=""),location.protocol==="chrome:"){if(console.warn("Cannot run extension on chrome:// pages."),c&&(c.style.display="none"),x){const A=document.createElement("div");A.textContent="🚫 Not supported on chrome:// pages.",x.appendChild(A)}return}try{ce({type:"GET_BOOKMARKS"},A=>{if(!A){Be(s);return}const H=(A==null?void 0:A.bookmarks)||[];de(["bookmarkClicks","bookmark_categories"],D=>{const Q=(D==null?void 0:D.bookmarkClicks)||{},J=Array.isArray(D==null?void 0:D.bookmark_categories)?D.bookmark_categories:[];c&&(c.style.display="none"),x&&(x.innerHTML="");const re=new ue(H,{keys:["title","url"],includeScore:!0,threshold:.4,distance:100,useExtendedSearch:!0});function V(X,q){let v=q;return X.trim()&&(v=re.search(X).map(R=>R.item)),v}C.oninput=()=>{const X=C.value.toLowerCase();if(x.innerHTML="",B=[],S=-1,Lt(X),Bt(X),X.trim()===""){F(H,Q,s);return}const q=V(X,H);if(q.length===0){const v=document.createElement("div");v.textContent="🔍 No bookmarks found.",x.appendChild(v);return}q.forEach(v=>{const w=document.createElement("li"),R=v.title,m=Q[R]||0;let W="Uncategorized",ie="#6366f1";if(v.categoryId){const Y=J.find(z=>z.id===v.categoryId);Y&&(W=Y.name,ie=Y.color||"#6366f1")}w.innerHTML=`
                <span style="background:${ie};color:#fff;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:600;display:inline-block;margin-right:10px;">${W}</span>
              <img src="https://www.google.com/s2/favicons?domain=${v.url}" style="width:16px; height:16px; margin-right:8px; vertical-align:middle; border-radius:4px;">
              <span class="bookmark-title">${v.title}</span>
                <span class="bookmark-clicks" style="margin-left: 6px;">(${m})</span>
            `,w.classList.add("show");const _=s.classList.contains("light-mode");w.style.background=_?"#f3f4f6":"#23272f",w.style.color=_?"#222":"#fff",w.style.display="flex",w.style.alignItems="center",w.style.padding="14px 18px",w.style.margin="0 0 2px 0",w.style.borderRadius="8px",w.style.fontSize="16px",w.style.boxShadow=_?"0 1px 4px rgba(0,0,0,0.04)":"0 1px 4px rgba(0,0,0,0.18)",w.style.transition="background 0.2s, color 0.2s",w.onmouseenter=()=>{w.style.background=_?"#e5e7eb":"#38404d"},w.onmouseleave=()=>{w.style.background=_?"#f3f4f6":"#23272f"};const Z=w.querySelector(".bookmark-clicks");Z&&(Z.style.color=_?"#666":"#bbb"),w.onclick=()=>{if(!le()){alert("🚫 Bookmark open failed. Extension context was lost.");return}chrome.storage.local.get("bookmarkClicks",Y=>{const z=Y.bookmarkClicks||{};z[R]=(z[R]||0)+1,chrome.storage.local.set({bookmarkClicks:z},()=>{window.open(v.url,"_blank"),L()})})},x.appendChild(w),B.push({element:w,data:v})}),S=B.length>0?0:-1,T&&T()},F(H,Q,s)})})}catch(A){console.error("sendMessage threw exception:",A),Be(s)}}function F(s,c,x){chrome.storage.local.get(["forethought_expandRecent","forethought_expandTop","forethought_recentLimit","forethought_topLimit"],C=>{const A=C.forethought_expandRecent===!0||C.forethought_expandRecent==="true",H=C.forethought_expandTop===!0||C.forethought_expandTop==="true",D=parseInt(C.forethought_recentLimit)||5,Q=parseInt(C.forethought_topLimit)||5,J=x.querySelector("#searchResults");if(!J||(J.innerHTML="",B=[],S=-1,s.length===0))return;const re=document.createElement("div");re.textContent="🆕 Recently Added",re.style="padding: 8px 16px; font-size: 14px; font-weight: bold; color: gray; cursor: pointer;",J.appendChild(re);const V=document.createElement("div");V.style.display=A?"block":"none",J.appendChild(V),re.onclick=()=>{V.style.display=V.style.display==="none"?"block":"none"},s.slice(-D).reverse().forEach(R=>{const m=document.createElement("li"),W=R.title,ie=c[W]||0;m.innerHTML=`
        <img src="https://www.google.com/s2/favicons?domain=${R.url}" style="width:16px; height:16px; margin-right:8px; vertical-align:middle; border-radius:4px;">
        <span class="bookmark-title">${R.title}</span>
          <span class="bookmark-clicks" style="margin-left: 6px;">(${ie})</span>
      `,m.classList.add("show");const _=x.classList.contains("light-mode");m.style.background=_?"#f3f4f6":"#23272f",m.style.color=_?"#222":"#fff",m.style.display="flex",m.style.alignItems="center",m.style.padding="14px 18px",m.style.margin="0 0 2px 0",m.style.borderRadius="8px",m.style.fontSize="16px",m.style.boxShadow=_?"0 1px 4px rgba(0,0,0,0.04)":"0 1px 4px rgba(0,0,0,0.18)",m.style.transition="background 0.2s, color 0.2s",m.onmouseenter=()=>{m.style.background=_?"#e5e7eb":"#38404d"},m.onmouseleave=()=>{m.style.background=_?"#f3f4f6":"#23272f"};const Z=m.querySelector(".bookmark-clicks");Z&&(Z.style.color=_?"#666":"#bbb"),m.onclick=()=>{if(!le()){alert("🚫 Bookmark open failed. Extension context was lost.");return}chrome.storage.local.get("bookmarkClicks",Y=>{const z=Y.bookmarkClicks||{};z[W]=(z[W]||0)+1,chrome.storage.local.set({bookmarkClicks:z},()=>{window.open(R.url,"_blank"),L()})})},V.appendChild(m),B.push({element:m,data:R})});const q=document.createElement("div");q.textContent="🌟 Top Bookmarks",q.style="padding: 8px 16px; font-size: 14px; font-weight: bold; color: gray; margin-top: 16px; cursor: pointer;",J.appendChild(q);const v=document.createElement("div");v.style.display=H?"block":"none",J.appendChild(v),q.onclick=()=>{v.style.display=v.style.display==="none"?"block":"none"},s.slice(0,Q).forEach(R=>{const m=document.createElement("li"),W=R.title,ie=c[W]||0;m.innerHTML=`
        <img src="https://www.google.com/s2/favicons?domain=${R.url}" style="width:16px; height:16px; margin-right:8px; vertical-align:middle; border-radius:4px;">
        <span class="bookmark-title">${R.title}</span>
          <span class="bookmark-clicks" style="margin-left: 6px;">(${ie})</span>
      `,m.classList.add("show");const _=x.classList.contains("light-mode");m.style.background=_?"#f3f4f6":"#23272f",m.style.color=_?"#222":"#fff",m.style.display="flex",m.style.alignItems="center",m.style.padding="14px 18px",m.style.margin="0 0 2px 0",m.style.borderRadius="8px",m.style.fontSize="16px",m.style.boxShadow=_?"0 1px 4px rgba(0,0,0,0.04)":"0 1px 4px rgba(0,0,0,0.18)",m.style.transition="background 0.2s, color 0.2s",m.onmouseenter=()=>{m.style.background=_?"#e5e7eb":"#38404d"},m.onmouseleave=()=>{m.style.background=_?"#f3f4f6":"#23272f"};const Z=m.querySelector(".bookmark-clicks");Z&&(Z.style.color=_?"#666":"#bbb"),m.onclick=()=>{if(!le()){alert("🚫 Bookmark open failed. Extension context was lost.");return}chrome.storage.local.get("bookmarkClicks",Y=>{const z=Y.bookmarkClicks||{};z[W]=(z[W]||0)+1,chrome.storage.local.set({bookmarkClicks:z},()=>{window.open(R.url,"_blank"),L()})})},v.appendChild(m),B.push({element:m,data:R})}),V&&$(V),v&&$(v),S=B.length>0?0:-1,T&&T()})}window.showSuggestions=F;let S=-1,B=[],oe=!1;function I(){oe||(oe=!0,document.addEventListener("keydown",s=>{if((s.metaKey||s.ctrlKey)&&s.key.toLowerCase()==="k"&&(s.preventDefault(),E()),n.classList.contains("active")&&(s.key==="Escape"&&(s.preventDefault(),L()),(s.key==="ArrowDown"||s.key==="Tab"&&!s.shiftKey)&&(s.preventDefault(),B.length>0&&(S=(S+1)%B.length,T())),(s.key==="ArrowUp"||s.key==="Tab"&&s.shiftKey)&&(s.preventDefault(),B.length>0&&(S=(S-1+B.length)%B.length,T())),s.key==="Enter"&&(s.preventDefault(),S>=0&&B[S]))){const{data:c}=B[S],x=c.title;chrome.storage.local.get("bookmarkClicks",C=>{const A=C.bookmarkClicks||{};A[x]=(A[x]||0)+1,chrome.storage.local.set({bookmarkClicks:A},()=>{s.metaKey||s.ctrlKey?window.open(c.url,"_blank"):window.location.href=c.url,L()})})}}))}I(),n.addEventListener("click",s=>{s.target===n&&L()});function T(){B.forEach((s,c)=>{c===S?s.element.classList.add("active"):s.element.classList.remove("active")})}const G=r.querySelector("#resetClicksButton"),ne=r.querySelector("#onboardingTourButton");G.onclick=()=>{confirm("Are you sure you want to reset all bookmark click counts?")&&chrome.storage.local.remove("bookmarkClicks",()=>{alert("Click stats reset successfully!"),i.classList.contains("active")&&ce({type:"GET_BOOKMARKS"},s=>{const c=(s==null?void 0:s.bookmarks)||[];F(c,{},i)})})},ne.onclick=()=>{const s=e.querySelector("#global-search-onboarding");s&&s.remove(),ne.style.background="rgba(59,130,246,0.25)",setTimeout(()=>{ne.style.background="rgba(59,130,246,0.15)"},200),k(e)};const P=r.querySelector("#expandRecentToggle"),O=r.querySelector("#expandTopToggle"),se=r.querySelector("#recentLimitInput"),M=r.querySelector("#topLimitInput");P.addEventListener("change",s=>{chrome.storage.local.set({forethought_expandRecent:s.target.checked});const{recentList:c}=f();c&&(c.style.display=s.target.checked?"block":"none")}),O.addEventListener("change",s=>{chrome.storage.local.set({forethought_expandTop:s.target.checked});const{topList:c}=f();c&&(c.style.display=s.target.checked?"block":"none")}),se.addEventListener("input",s=>{chrome.storage.local.set({forethought_recentLimit:s.target.value})}),M.addEventListener("input",s=>{chrome.storage.local.set({forethought_topLimit:s.target.value})}),St();function $(s){if(!s)return;const c=i.classList.contains("light-mode");s.style.background=c?"#f3f4f6":"#2e3138",s.style.color=c?"#222":"#fff",s.style.borderRadius="10px",s.style.padding="8px 0",s.style.marginBottom="8px",s.style.boxShadow=c?"0 2px 8px rgba(0,0,0,0.04)":"0 2px 8px rgba(0,0,0,0.18)"}function he(){chrome.storage.local.get(["forethought_expandRecent","forethought_expandTop","forethought_recentLimit","forethought_topLimit","forethought_overlay_opacity","forethought_theme"],s=>{if(P.checked=s.forethought_expandRecent===!0||s.forethought_expandRecent==="true",O.checked=s.forethought_expandTop===!0||s.forethought_expandTop==="true",se.value=s.forethought_recentLimit||5,M.value=s.forethought_topLimit||5,h&&s.forethought_overlay_opacity&&(h.value=s.forethought_overlay_opacity,n.style.background=`rgba(0, 0, 0, ${s.forethought_overlay_opacity})`),s.forethought_theme==="light"?(i.classList.add("light-mode"),d.checked=!0,g.textContent="☀️"):(i.classList.remove("light-mode"),d.checked=!1,g.textContent="🌙"),i.classList.contains("active")){const{recentList:c,topList:x}=f();c&&(c.style.display=P.checked?"block":"none",$(c)),x&&(x.style.display=O.checked?"block":"none",$(x))}})}const Ke=E;if(E=function(){he(),Ke()},d.addEventListener("change",s=>{setTimeout(()=>{const{recentList:c,topList:x}=f();c&&$(c),x&&$(x)},50)}),P.addEventListener("change",s=>{chrome.storage.local.set({forethought_expandRecent:s.target.checked});const{recentList:c}=f();c&&(c.style.display=s.target.checked?"block":"none",$(c))}),O.addEventListener("change",s=>{chrome.storage.local.set({forethought_expandTop:s.target.checked});const{topList:c}=f();c&&(c.style.display=s.target.checked?"block":"none",$(c))}),se.addEventListener("input",s=>{chrome.storage.local.set({forethought_recentLimit:s.target.value}),i.classList.contains("active")&&ce({type:"GET_BOOKMARKS"},c=>{const x=(c==null?void 0:c.bookmarks)||[];de("bookmarkClicks",C=>{const A=(C==null?void 0:C.bookmarkClicks)||{};F(x,A,i)})})}),M.addEventListener("input",s=>{chrome.storage.local.set({forethought_topLimit:s.target.value}),i.classList.contains("active")&&ce({type:"GET_BOOKMARKS"},c=>{const x=(c==null?void 0:c.bookmarks)||[];de("bookmarkClicks",C=>{const A=(C==null?void 0:C.bookmarkClicks)||{};F(x,A,i)})})}),!E._patched){const s=E;E=function(){he(),s()},E._patched=!0}}function Lt(t){t.trim()&&chrome.storage.local.get(ae.SEARCH_HISTORY,e=>{const o=e[ae.SEARCH_HISTORY]||[],n=[t,...o.filter(r=>r!==t)].slice(0,10);chrome.storage.local.set({[ae.SEARCH_HISTORY]:n})})}function Bt(t){t.trim()&&chrome.storage.local.get(ae.SEARCH_SUGGESTIONS,e=>{const o=e[ae.SEARCH_SUGGESTIONS]||{};o[t]=(o[t]||0)+1,chrome.storage.local.set({[ae.SEARCH_SUGGESTIONS]:o})})}
